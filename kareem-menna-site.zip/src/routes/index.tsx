import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { FloatingHearts } from "@/components/hearts";
import { Games } from "@/components/games";
import {
  Countdown,
  Gallery,
  Reasons,
  SectionTitle,
  Timeline,
  Truths,
  gallery,
} from "@/components/sections";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "مملكة كريم و منه 💍" },
      {
        name: "description",
        content: "موقع رومانسي تفاعلي لكريم ومنه: ذكريات، ألعاب، أسئلة صراحة، و٥٠ سبب للحب.",
      },
      { property: "og:title", content: "مملكة كريم و منه 💍" },
      {
        property: "og:description",
        content: "ادخلي عالمنا: ذكرياتنا، ألعابنا، وكل كلمة حب اتكتبت ليكي.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const SECRET = "menna";

function Index() {
  const [phase, setPhase] = useState<"gate" | "loading" | "site">("gate");
  const [value, setValue] = useState("");
  const [wrong, setWrong] = useState(false);

  useEffect(() => {
    if (phase !== "loading") return;
    const t = setTimeout(() => setPhase("site"), 2600);
    return () => clearTimeout(t);
  }, [phase]);

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (value.trim().toLowerCase() === SECRET) {
      setWrong(false);
      setPhase("loading");
    } else {
      setWrong(true);
    }
  }

  if (phase !== "site") {
    return (
      <main className="relative flex min-h-screen items-center justify-center px-4">
        <FloatingHearts count={14} />
        {phase === "loading" ? (
          <div className="relative z-10 text-center">
            <div className="animate-beat text-6xl">💖</div>
            <p className="mt-4 text-xl text-accent">جاري التحميل...</p>
            <p className="mt-1 text-sm text-muted-foreground">ثواني ي روحي معلش ❤️</p>
          </div>
        ) : (
          <form
            onSubmit={submit}
            className={`glass-card neon-ring relative z-10 w-full max-w-md px-6 pb-8 pt-16 text-center ${
              wrong ? "animate-shake" : ""
            }`}
          >
            <img
              src={gallery[0]}
              alt="كريم و منه"
              width={1024}
              height={1024}
              className="neon-ring absolute -top-12 right-1/2 h-24 w-24 translate-x-1/2 rounded-full border-2 border-primary object-cover"
            />
            <div className="text-3xl">💖</div>
            <h1 className="mt-2 text-3xl neon-text sm:text-4xl">مملكة كريم و منه 💍</h1>
            <p className="mt-2 text-sm text-muted-foreground">مفتاح قلب كريم إيه؟</p>
            <input
              value={value}
              onChange={(e) => setValue(e.target.value)}
              placeholder="اكتبي رسالتك هنا..."
              className="mt-5 w-full rounded-2xl bg-input px-4 py-4 text-center outline-none focus:ring-2 focus:ring-ring"
            />
            <button
              type="submit"
              className="mt-4 w-full rounded-full py-4 text-lg font-bold text-primary-foreground transition-transform hover:scale-[1.02]"
              style={{ background: "var(--gradient-romance)", boxShadow: "var(--shadow-neon)" }}
            >
              ادخلي عالمنا ❤️
            </button>
            {wrong ? <p className="mt-3 text-sm text-destructive">لا ركزي، الكلمة غلط!</p> : null}
          </form>
        )}
      </main>
    );
  }

  return <Site />;
}

function Site() {
  const rootRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const els = rootRef.current?.querySelectorAll(".reveal") ?? [];
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => e.isIntersecting && e.target.classList.add("is-visible"));
      },
      { threshold: 0.12 },
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);

  return (
    <div ref={rootRef} className="relative">
      <FloatingHearts />

      <main className="relative z-10 mx-auto max-w-5xl px-4 pb-28 pt-12">
        {/* Hero */}
        <section id="home" className="scroll-mt-20 text-center">
          <img
            src={gallery[0]}
            alt="كريم و منه"
            width={1024}
            height={1024}
            className="neon-ring mx-auto h-32 w-32 rounded-full border-2 border-primary object-cover"
          />
          <h1 className="mt-5 text-4xl neon-text sm:text-6xl">مملكة كريم و منه 💍</h1>
          <p className="mt-3 text-lg text-accent">حياتي معاكي بقت كده 👇</p>
          <h2 className="mt-8 text-3xl text-primary-glow neon-text">بحبك يا نور عيني 💖</h2>
          <p className="mt-2 text-muted-foreground">إنتي أجمل تريند في حياتي</p>
        </section>

        {/* Letter */}
        <section className="mt-14">
          <SectionTitle>رسالة خاصة ليكي ✨</SectionTitle>
          <div className="glass-card reveal mx-auto max-w-2xl p-6 text-center text-lg leading-loose">
            إنتي مش بس خطيبتي، إنتي دنيتي كلها اللي كنت مستنيها.. كل يوم بيعدي وإحنا سوا هو عيد
            بالنسبة لي. ❤️
          </div>
        </section>

        {/* Countdown */}
        <section className="mt-14">
          <SectionTitle>الوقت معاكي بيطير ⏳</SectionTitle>
          <div className="reveal mx-auto max-w-xl">
            <Countdown />
          </div>
        </section>

        {/* Timeline */}
        <section className="mt-14">
          <SectionTitle>خريطة طريق حبنا 📍❤️</SectionTitle>
          <Timeline />
        </section>

        {/* Gallery */}
        <section id="memories" className="mt-14 scroll-mt-20">
          <SectionTitle>أحلى ذكرياتنا 📸❤️</SectionTitle>
          <Gallery />
        </section>

        {/* Games */}
        <section id="games" className="mt-14 scroll-mt-20">
          <SectionTitle>ألعابنا 🎮</SectionTitle>
          <Games />
        </section>

        {/* Truths */}
        <section id="truths" className="mt-14 scroll-mt-20">
          <SectionTitle>أسئلة صراحة 🗣️❤️</SectionTitle>
          <Truths />
        </section>

        {/* Reasons */}
        <section className="mt-14">
          <SectionTitle>٥٠ سبب مخليني مجنون بيكي 🥰</SectionTitle>
          <Reasons />
        </section>

        {/* Footer */}
        <footer className="mt-16 text-center">
          <h2 className="text-3xl neon-text">بحبك يا منه يا روحي 💍</h2>
          <p className="mt-2 text-accent">كريم</p>
        </footer>
      </main>

      {/* Bottom nav */}
      <nav className="fixed bottom-0 left-0 right-0 z-30 border-t border-border bg-card/90 backdrop-blur-md">
        <div className="mx-auto flex max-w-md items-center justify-around py-2 text-xs">
          {[
            { href: "#home", icon: "🏠", label: "الرئيسية" },
            { href: "#memories", icon: "📸", label: "ذكرياتنا" },
            { href: "#games", icon: "🎮", label: "ألعابنا" },
            { href: "#truths", icon: "❓", label: "أسئلة" },
          ].map((l) => (
            <a key={l.href} href={l.href} className="flex flex-col items-center gap-1 px-3 py-1">
              <span className="text-lg">{l.icon}</span>
              <span className="text-muted-foreground">{l.label}</span>
            </a>
          ))}
        </div>
      </nav>
    </div>
  );
}
