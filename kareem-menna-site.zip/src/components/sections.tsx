import { useEffect, useState } from "react";
import img1 from "@/assets/couple-1.jpg";
import img2 from "@/assets/couple-2.jpg";
import img3 from "@/assets/couple-3.jpg";
import img4 from "@/assets/couple-4.jpg";

export const gallery = [img1, img2, img3, img4];

export function SectionTitle({ children }: { children: string }) {
  return (
    <h2 className="reveal mb-6 text-center text-3xl text-primary-glow neon-text sm:text-4xl">
      {children}
    </h2>
  );
}

/* ---------- Countdown ---------- */
const START = new Date("2024-02-14T20:00:00+02:00").getTime();

export function Countdown() {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  const diff = Math.max(0, now - START);
  const days = Math.floor(diff / 86400000);
  const hours = Math.floor((diff / 3600000) % 24);
  const mins = Math.floor((diff / 60000) % 60);
  const secs = Math.floor((diff / 1000) % 60);
  const items = [
    { label: "يوم", value: days },
    { label: "ساعة", value: hours },
    { label: "دقيقة", value: mins },
    { label: "ثانية", value: secs },
  ];

  return (
    <div className="grid grid-cols-4 gap-3">
      {items.map((i) => (
        <div key={i.label} className="glass-card animate-glow-pulse p-4 text-center">
          <div className="text-2xl font-bold text-accent sm:text-3xl">{i.value}</div>
          <div className="text-xs text-muted-foreground">{i.label}</div>
        </div>
      ))}
    </div>
  );
}

/* ---------- Timeline ---------- */
const timeline = [
  { icon: "👋", title: "أول ما شوفتك", text: "قلبي وقع من أول نظرة ومعرفتش أخبي ابتسامتي." },
  { icon: "💬", title: "أول كلام", text: "اتكلمنا لحد الفجر وحسيت إني أعرفك من سنين." },
  { icon: "🌊", title: "أول خروجة", text: "البحر كان شاهد على أول مرة أقولك بحبك." },
  { icon: "💍", title: "يوم الخطوبة", text: "أحلى يوم في عمري، بقيتي رسمياً نصيبي." },
  { icon: "♾️", title: "اللي جاي", text: "عمر كامل مع بعض.. وأنا مستني كل ثانية فيه." },
];

export function Timeline() {
  return (
    <div className="relative mx-auto max-w-2xl">
      <div className="absolute bottom-0 right-6 top-0 w-px bg-border" />
      <div className="space-y-5">
        {timeline.map((t) => (
          <div key={t.title} className="reveal glass-card relative mr-14 p-5">
            <span
              className="absolute -right-14 top-5 flex h-10 w-10 items-center justify-center rounded-full text-lg"
              style={{ background: "var(--gradient-romance)", boxShadow: "var(--shadow-neon)" }}
            >
              {t.icon}
            </span>
            <h3 className="text-xl text-accent">{t.title}</h3>
            <p className="mt-1 text-sm text-muted-foreground leading-relaxed">{t.text}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------- Gallery ---------- */
export function Gallery() {
  const [open, setOpen] = useState<number | null>(null);
  return (
    <>
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        {gallery.map((src, i) => (
          <button
            key={src}
            type="button"
            onClick={() => setOpen(i)}
            className="reveal group overflow-hidden rounded-2xl border border-border"
          >
            <img
              src={src}
              alt={`ذكرى ${i + 1}`}
              loading="lazy"
              width={1024}
              height={1024}
              className="h-40 w-full object-cover transition-transform duration-500 group-hover:scale-110 sm:h-48"
            />
          </button>
        ))}
      </div>

      {open !== null ? (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-background/90 p-4"
          onClick={() => setOpen(null)}
        >
          <div className="relative max-w-2xl" onClick={(e) => e.stopPropagation()}>
            <img src={gallery[open]} alt="ذكرى" className="max-h-[80vh] rounded-2xl" />
            <div className="mt-4 flex justify-center gap-4">
              <button
                type="button"
                onClick={() => setOpen((o) => ((o ?? 0) + 1) % gallery.length)}
                className="rounded-full bg-secondary px-5 py-2"
              >
                ❯
              </button>
              <button
                type="button"
                onClick={() => setOpen(null)}
                className="rounded-full bg-primary px-5 py-2 text-primary-foreground"
              >
                ✕
              </button>
              <button
                type="button"
                onClick={() => setOpen((o) => ((o ?? 0) - 1 + gallery.length) % gallery.length)}
                className="rounded-full bg-secondary px-5 py-2"
              >
                ❮
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
}

/* ---------- Truth questions ---------- */
const truths = [
  "إيه أول حاجة خلتك تحبيني؟",
  "أكتر موقف بينا مش بتنسيه؟",
  "لو نرجع أول يوم، هتغيري حاجة؟",
  "إيه الحاجة اللي نفسك نعملها مع بعض قريب؟",
  "أكتر كلمة بتحبي تسمعيها مني؟",
  "إيه أحلى مفاجأة تتخيليها مني؟",
];

export function Truths() {
  const [q, setQ] = useState<string | null>(null);
  return (
    <div className="glass-card reveal mx-auto max-w-xl p-6 text-center">
      <p className="min-h-16 text-xl text-accent">{q ?? "دوسي عشان تطلع سؤال صراحة 🗣️"}</p>
      <button
        type="button"
        onClick={() => setQ(truths[Math.floor(Math.random() * truths.length)] ?? truths[0]!)}
        className="mt-4 rounded-full px-6 py-3 font-bold text-primary-foreground"
        style={{ background: "var(--gradient-romance)", boxShadow: "var(--shadow-neon)" }}
      >
        اسحبي سؤال 🎲
      </button>
    </div>
  );
}

/* ---------- Reasons ---------- */
const reasonSeeds = [
  "ضحكتك",
  "صوتك في التليفون",
  "طيبة قلبك",
  "طريقة كلامك",
  "اهتمامك بالتفاصيل",
  "دعواتك ليا",
  "حضنك",
  "رسايلك الصغيرة",
  "غيرتك الحلوة",
  "صبرك عليا",
  "ذكاءك",
  "عيونك",
  "ريحتك",
  "أكلك",
  "خفة دمك",
  "حنيتك",
  "شكلك وانتي زعلانة",
  "نص الليل وإحنا بنتكلم",
  "دلعك",
  "إنك بتفهميني من نظرة",
];

export function Reasons() {
  const [count, setCount] = useState(8);
  const list = Array.from({ length: 50 }, (_, i) => reasonSeeds[i % reasonSeeds.length]);
  return (
    <div className="mx-auto max-w-3xl">
      <div className="grid gap-3 sm:grid-cols-2">
        {list.slice(0, count).map((r, i) => (
          <div key={i} className="glass-card flex items-center gap-3 p-3 text-sm">
            <span className="text-accent">{i + 1}.</span>
            <span>{r} 💖</span>
          </div>
        ))}
      </div>
      {count < 50 ? (
        <div className="mt-5 text-center">
          <button
            type="button"
            onClick={() => setCount((c) => Math.min(50, c + 12))}
            className="rounded-full px-6 py-3 font-bold text-primary-foreground"
            style={{ background: "var(--gradient-romance)", boxShadow: "var(--shadow-neon)" }}
          >
            كملي باقي الأسباب ✨
          </button>
        </div>
      ) : (
        <p className="mt-5 text-center text-accent">و٥٠٠ سبب تاني مش بيتكتبوا يا منه ❤️</p>
      )}
    </div>
  );
}
