import type { ReactNode } from "react";

export function GameCard({
  index,
  title,
  desc,
  children,
}: {
  index: number;
  title: string;
  desc?: string;
  children: ReactNode;
}) {
  return (
    <div className="glass-card reveal flex flex-col gap-3 p-5 text-center">
      <h3 className="text-2xl text-primary-glow neon-text">
        <span className="text-muted-foreground text-lg">{index}. </span>
        {title}
      </h3>
      {desc ? <p className="text-sm text-muted-foreground leading-relaxed">{desc}</p> : null}
      <div className="flex flex-1 flex-col items-center justify-center gap-3">{children}</div>
    </div>
  );
}

export function LoveButton({
  children,
  onClick,
  disabled,
}: {
  children: ReactNode;
  onClick?: () => void;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className="rounded-full px-6 py-3 text-base font-bold text-primary-foreground transition-transform duration-200 hover:scale-105 active:scale-95 disabled:opacity-50"
      style={{ background: "var(--gradient-romance)", boxShadow: "var(--shadow-neon)" }}
    >
      {children}
    </button>
  );
}

export function Result({ children }: { children: ReactNode }) {
  if (!children) return null;
  return (
    <p className="rounded-xl bg-secondary/70 px-4 py-3 text-base font-semibold text-accent">
      {children}
    </p>
  );
}
