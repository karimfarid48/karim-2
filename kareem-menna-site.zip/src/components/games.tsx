import { useEffect, useRef, useState } from "react";
import { GameCard, LoveButton, Result } from "./game-card";

/* 1 */
function ReactionGame() {
  const [state, setState] = useState<"idle" | "wait" | "go" | "done">("idle");
  const [ms, setMs] = useState(0);
  const start = useRef(0);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(
    () => () => {
      if (timer.current) clearTimeout(timer.current);
    },
    [],
  );

  function begin() {
    setState("wait");
    timer.current = setTimeout(
      () => {
        start.current = Date.now();
        setState("go");
      },
      900 + Math.random() * 2200,
    );
  }

  return (
    <GameCard index={1} title="اختبار السرعة ⚡" desc="لما المربع يبقى لونه أخضر دوسي عليه بسرعة!">
      <button
        type="button"
        onClick={() => {
          if (state === "go") {
            setMs(Date.now() - start.current);
            setState("done");
          } else if (state === "idle" || state === "done") begin();
        }}
        className="flex h-28 w-28 items-center justify-center rounded-2xl text-3xl transition-colors"
        style={{
          background:
            state === "go" ? "oklch(0.72 0.2 150)" : state === "wait" ? "var(--destructive)" : "var(--secondary)",
        }}
      >
        {state === "go" ? "دوسي!" : state === "wait" ? "استني…" : "⚡"}
      </button>
      {state === "done" ? <Result>{`سرعتك ${ms} جزء من الثانية.. قلبي أسرع منك 😍`}</Result> : null}
      {state === "idle" ? <p className="text-xs text-muted-foreground">دوسي على المربع للبدء</p> : null}
    </GameCard>
  );
}

/* 2 */
function CallGame() {
  const [status, setStatus] = useState<"ringing" | "answered" | "rejected">("ringing");
  return (
    <GameCard index={2} title="مكالمة طارئة 📞" desc="حبيب القلب بيرن.. تردي؟">
      <div className="text-5xl animate-beat">📱</div>
      {status === "ringing" ? (
        <div className="flex gap-3">
          <LoveButton onClick={() => setStatus("answered")}>رد 📞</LoveButton>
          <button
            type="button"
            onClick={() => setStatus("rejected")}
            className="rounded-full bg-secondary px-5 py-3 font-bold"
          >
            رفض ❌
          </button>
        </div>
      ) : (
        <Result>
          {status === "answered"
            ? "كريم: وحشتيني موت يا منه ❤️"
            : "رفضتي؟ طيب هفضل أرن لحد ما تردي 😢"}
        </Result>
      )}
    </GameCard>
  );
}

/* 3 */
function BatteryGame() {
  const [pct, setPct] = useState(12);
  return (
    <GameCard index={3} title="بطارية قلبي 🔋" desc="قلبي بيفصل لما بتبعدي، اضغطي عشان تشحنيه:">
      <div className="h-6 w-full max-w-60 overflow-hidden rounded-full bg-secondary">
        <div
          className="h-full transition-all duration-500"
          style={{ width: `${pct}%`, background: "var(--gradient-romance)" }}
        />
      </div>
      <span className="text-lg font-bold text-accent">{pct}%</span>
      <LoveButton onClick={() => setPct((p) => Math.min(100, p + 11))}>اشحني قلبي ⚡</LoveButton>
      {pct >= 100 ? <Result>شحنت بالكامل بحبك 💖</Result> : null}
    </GameCard>
  );
}

/* 4 */
function PrescriptionGame() {
  const [open, setOpen] = useState(false);
  return (
    <GameCard index={4} title="روشتة السعادة 💊">
      <LoveButton onClick={() => setOpen(true)}>اصرفي الروشتة 🩺</LoveButton>
      {open ? (
        <div className="space-y-1 rounded-xl bg-secondary/70 p-4 text-sm">
          <p className="font-bold">دواعي الاستعمال: للوقاية من النكد.</p>
          <p>الجرعة: ٣ حضن يومياً + مكالمة قبل النوم.</p>
          <p className="italic text-muted-foreground">ملاحظات: ممنوع الزعل نهائياً!</p>
        </div>
      ) : null}
    </GameCard>
  );
}

/* 5 */
function CrazyCalculator() {
  const [a, setA] = useState("");
  const [b, setB] = useState("");
  const [out, setOut] = useState("");
  return (
    <GameCard index={5} title="الآلة الحاسبة المجنونة 🧮" desc="احسبي أي حاجة وشوفي النتيجة:">
      <div className="flex items-center gap-2">
        <input
          value={a}
          onChange={(e) => setA(e.target.value)}
          inputMode="numeric"
          className="w-16 rounded-lg bg-input px-2 py-2 text-center"
          placeholder="٢"
        />
        <span>+</span>
        <input
          value={b}
          onChange={(e) => setB(e.target.value)}
          inputMode="numeric"
          className="w-16 rounded-lg bg-input px-2 py-2 text-center"
          placeholder="٢"
        />
      </div>
      <LoveButton onClick={() => setOut("بحبك 💖")}>يساوي =</LoveButton>
      {out ? <Result>{`${a || "٢"} + ${b || "٢"} = ${out}`}</Result> : null}
    </GameCard>
  );
}

/* 6 */
function SeaButton() {
  const [on, setOn] = useState(false);
  return (
    <GameCard
      index={6}
      title="زرار الروقان 🌊"
      desc="لو متضايقة، الزرار ده هيجيبلك ريحة وموج بحر إسكندرية لحد عندك:"
    >
      <LoveButton onClick={() => setOn((v) => !v)}>خديني معاكي ع البحر 🏖️</LoveButton>
      {on ? (
        <div className="w-full rounded-xl bg-secondary/70 p-4 text-3xl tracking-widest">
          🌊🌊🌊🌊🌊
          <p className="mt-2 text-sm text-muted-foreground">خدي نفس عميق.. أنا جانبك ❤️</p>
        </div>
      ) : null}
    </GameCard>
  );
}

/* 7 */
function VipCard() {
  const [show, setShow] = useState(false);
  return (
    <GameCard index={7} title="كارنيه الـ VIP 🎟️">
      <LoveButton onClick={() => setShow(true)}>اعرضي هويتك</LoveButton>
      {show ? (
        <div
          className="w-full rounded-2xl p-4 text-right text-accent-foreground"
          style={{ background: "var(--gradient-romance)" }}
        >
          <p className="font-bold">VIP Access Card</p>
          <p className="mt-1 text-sm font-bold">الاسم: منه هانم</p>
          <p className="text-sm">
            الصلاحيات: الدخول لقلب كريم بدون استئذان، التحكم في المود، طلب أي أكل في أي وقت.
          </p>
        </div>
      ) : null}
    </GameCard>
  );
}

/* 8 */
function PiggyBank() {
  const [coins, setCoins] = useState(0);
  return (
    <GameCard index={8} title="حصالة الذكريات 🐷" desc="حصالة بنحوش فيها حب، حطي كوين:">
      <div className="text-5xl">🐷</div>
      <LoveButton onClick={() => setCoins((c) => c + 1)}>🪙 حطي كوين</LoveButton>
      <Result>{coins > 0 ? `جمعنا ${coins} ذكرى حلوة مع بعض 💕` : ""}</Result>
    </GameCard>
  );
}

/* 9 */
const stations: Record<string, string> = {
  "محطة الغزل 💌": "إنتي أحلى حاجة حصلت لي في حياتي يا منه",
  "محطة الشوق 🌙": "بعدك عني ثانية بيبقى سنة.. وحشتيني",
  "محطة الضحك 😂": "لما تضحكي الدنيا كلها بتنور، كملي ضحك",
};
function LoveRadio() {
  const [st, setSt] = useState("");
  return (
    <GameCard index={9} title="راديو العشاق 📻" desc="اختاري المحطة اللي على مزاجك:">
      <select
        value={st}
        onChange={(e) => setSt(e.target.value)}
        className="rounded-xl bg-input px-4 py-3 text-center"
      >
        <option value="">اختاري محطة...</option>
        {Object.keys(stations).map((k) => (
          <option key={k} value={k}>
            {k}
          </option>
        ))}
      </select>
      {st ? <Result>{stations[st]}</Result> : null}
    </GameCard>
  );
}

/* 10 */
const fortunes = [
  "حظك النهاردة: حضن طويل من كريم 🤗",
  "بكرة هتوصلك مفاجأة صغيرة 🎁",
  "النصيب بيقول: عمر طويل مع بعض ❤️",
  "متقلقيش، كل اللي جاي أحلى 🌸",
];
function FortuneCookie() {
  const [f, setF] = useState("");
  return (
    <GameCard index={10} title="بسكوتة الحظ 🥠" desc="اكسري البسكوتة وشوفي حظك:">
      <button type="button" onClick={() => setF(fortunes[Math.floor(Math.random() * fortunes.length)] ?? fortunes[0]!)} className="text-5xl">
        🥠
      </button>
      {f ? <Result>{f}</Result> : null}
    </GameCard>
  );
}

/* 11 */
function CupidArrow() {
  const [hit, setHit] = useState<null | boolean>(null);
  return (
    <GameCard index={11} title="سهم كيوبيد 🏹" desc="اضربي السهم في نص قلبي بالظبط:">
      <div className="relative h-20 w-full">
        <span className="absolute left-1/2 top-2 -translate-x-1/2 text-4xl animate-beat">❤️</span>
        {hit !== null ? (
          <span className="absolute bottom-0 left-1/2 -translate-x-1/2 text-2xl">🏹</span>
        ) : null}
      </div>
      <LoveButton onClick={() => setHit(true)}>إطلاق السهم 💘</LoveButton>
      {hit ? <Result>أصبتي القلب في نصه بالظبط، القلب بقى ملكك 💘</Result> : null}
    </GameCard>
  );
}

/* 12 */
function FireExtinguisher() {
  const [n, setN] = useState(0);
  return (
    <GameCard index={12} title="طفاية الحريق 🧯" desc="عشان حلاوتك مولعة الدنيا، لازم نطفيها شوية!">
      <div className="text-5xl">{n > 2 ? "💦" : "🔥"}</div>
      <LoveButton onClick={() => setN((v) => v + 1)}>رشي الماية 💦</LoveButton>
      {n > 2 ? <Result>مفيش فايدة.. حلاوتك مش بتنطفي 😍</Result> : null}
    </GameCard>
  );
}

/* 13 */
function LongingThermometer() {
  const [t, setT] = useState<number | null>(null);
  return (
    <GameCard index={13} title="ترمومتر الشوق 🌡️" desc="شوفي درجة حرارة شوقي ليكي دلوقتي:">
      <div className="text-5xl">🌡️</div>
      <LoveButton onClick={() => setT(99 + Math.floor(Math.random() * 900))}>قيس الحرارة</LoveButton>
      {t ? <Result>{`${t}° مئوية.. الترمومتر انفجر من شوقي ليكي 🔥`}</Result> : null}
    </GameCard>
  );
}

/* 14 */
const cards = ["هتتحضني الليلة 🤗", "مكالمة لحد الفجر 📞", "خروجة على البحر 🌊", "حبة غزل زيادة 💌"];
function MagicCards() {
  const [pick, setPick] = useState<number | null>(null);
  return (
    <GameCard index={14} title="كوتشينة السحر 🃏" desc="اسحبي كارت عشوائي:">
      <div className="flex gap-3">
        {[0, 1, 2].map((i) => (
          <button
            key={i}
            type="button"
            onClick={() => setPick(Math.floor(Math.random() * cards.length))}
            className="h-20 w-14 rounded-xl bg-secondary text-2xl transition-transform hover:-translate-y-2"
          >
            🃏
          </button>
        ))}
      </div>
      {pick !== null ? <Result>{cards[pick]}</Result> : null}
    </GameCard>
  );
}

/* 15 */
function SadnessDetector() {
  const [step, setStep] = useState<"idle" | "scan" | "done">("idle");
  useEffect(() => {
    if (step !== "scan") return;
    const t = setTimeout(() => setStep("done"), 1800);
    return () => clearTimeout(t);
  }, [step]);
  return (
    <GameCard index={15} title="جهاز كشف الزعل 🕵️‍♂️" desc="بصي في الشاشة عشان نحلل ملامحك:">
      <div className={`text-5xl ${step === "scan" ? "animate-beat" : ""}`}>👁️</div>
      <LoveButton onClick={() => setStep("scan")} disabled={step === "scan"}>
        {step === "scan" ? "جاري الفحص..." : "بدء الفحص 👁️"}
      </LoveButton>
      {step === "done" ? <Result>النتيجة: زعل 0% وحب 100% إن شاء الله يدوم ❤️</Result> : null}
    </GameCard>
  );
}

/* 16 */
function Contract() {
  const [signed, setSigned] = useState(false);
  return (
    <GameCard
      index={16}
      title="عقد الاحتكار 📝"
      desc="بموجب هذا العقد، منه محتكرة قلب كريم مدى الحياة."
    >
      <LoveButton onClick={() => setSigned(true)} disabled={signed}>
        {signed ? "تم البصم ✅" : "أوافق وأبصم 🖋️"}
      </LoveButton>
      {signed ? <Result>العقد ساري.. ومفيش فيه بند إلغاء 💍</Result> : null}
    </GameCard>
  );
}

/* 17 */
function InfinityCounter() {
  const [n, setN] = useState(3552);
  useEffect(() => {
    const id = setInterval(() => setN((v) => v + 1), 90);
    return () => clearInterval(id);
  }, []);
  return (
    <GameCard index={17} title="عداد المالانهائية ♾️" desc="ده عداد حبي ليكي، حاولي توقفيه لو عرفتي!">
      <span className="text-3xl font-bold text-primary-glow neon-text">{n}</span>
      <LoveButton>وقفيه ✋</LoveButton>
      <p className="text-xs text-muted-foreground">مستحيل يوقف! حبي ليكي ملوش نهاية ❤️</p>
    </GameCard>
  );
}

/* 18 */
function LoveMagnifier() {
  const [big, setBig] = useState(false);
  return (
    <GameCard index={18} title="عدسة الحب المكبرة 🔍" desc="كلام صغير أوي مكتوب تحت، استخدمي العدسة:">
      <p
        className="transition-all duration-500 text-accent"
        style={{ fontSize: big ? "1.15rem" : "0.42rem" }}
      >
        أنا بعشقك يا منه ومقدرش أعيش من غيرك ثانية واحدة.
      </p>
      <LoveButton onClick={() => setBig((v) => !v)}>تكبير 🔍</LoveButton>
    </GameCard>
  );
}

/* 19 */
function NuclearButton() {
  const [boom, setBoom] = useState(false);
  return (
    <GameCard index={19} title="الزرار النووي للحب ☢️💥" desc="تحذير: لا تضغطي إلا في حالات العشق القصوى!">
      <div className={`text-5xl ${boom ? "animate-shake" : ""}`}>{boom ? "💥" : "☢️"}</div>
      <LoveButton onClick={() => setBoom(true)}>إطلاق القنبلة 🚀</LoveButton>
      {boom ? <Result>انفجر حب في كل مكان.. ومفيش نجاة من قلبي 💖</Result> : null}
    </GameCard>
  );
}

/* 20 */
function CatchHearts() {
  const [score, setScore] = useState(0);
  const [pos, setPos] = useState({ x: 40, y: 40 });
  const [playing, setPlaying] = useState(false);
  const [left, setLeft] = useState(15);

  useEffect(() => {
    if (!playing) return;
    const id = setInterval(() => setLeft((s) => Math.max(0, s - 1)), 1000);
    return () => clearInterval(id);
  }, [playing]);

  useEffect(() => {
    if (playing && left === 0) setPlaying(false);
  }, [playing, left]);

  return (
    <GameCard index={20} title="صيد القلوب 💘" desc="اصطادي أكبر عدد قلوب في ١٥ ثانية:">
      <div className="relative h-36 w-full overflow-hidden rounded-xl bg-secondary/60">
        {playing ? (
          <button
            type="button"
            onClick={() => {
              setScore((s) => s + 1);
              setPos({ x: Math.random() * 80, y: Math.random() * 70 });
            }}
            className="absolute text-3xl"
            style={{ left: `${pos.x}%`, top: `${pos.y}%` }}
          >
            ❤️
          </button>
        ) : (
          <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
            {score > 0 ? `صيدتي ${score} قلب 💖` : "دوسي ابدئي"}
          </div>
        )}
      </div>
      <div className="flex items-center gap-3">
        <LoveButton
          onClick={() => {
            setScore(0);
            setLeft(15);
            setPlaying(true);
          }}
          disabled={playing}
        >
          {playing ? `${left} ثانية` : "ابدئي 💘"}
        </LoveButton>
      </div>
    </GameCard>
  );
}

export function Games() {
  return (
    <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
      <ReactionGame />
      <CallGame />
      <BatteryGame />
      <PrescriptionGame />
      <CrazyCalculator />
      <SeaButton />
      <VipCard />
      <PiggyBank />
      <LoveRadio />
      <FortuneCookie />
      <CupidArrow />
      <FireExtinguisher />
      <LongingThermometer />
      <MagicCards />
      <SadnessDetector />
      <Contract />
      <InfinityCounter />
      <LoveMagnifier />
      <NuclearButton />
      <CatchHearts />
    </div>
  );
}
